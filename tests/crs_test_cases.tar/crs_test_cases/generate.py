"""Generate Vesta CRS test cases for validating planetarypy's CRS handling.

Produces two named-crater lists describing the SAME physical craters in two
different Vesta longitude frames, plus a synthetic edge-longitude table. All
outputs are generated with craterpy so the maintainers can check that their
CRS handling reproduces craterpy's frame transforms.

Frames (all standardize to IAU:200000400, ocentric, lon in -180..180):
    claudia_dp   = IAU_2015:200000400                         (offset   0 deg)
    claudia_p    = +proj=longlat +R=255000 +lon_0=+10         (offset +10 deg)
    dawn_claudia = +proj=longlat +R=255000 +lon_0=-210        (offset +150 deg)

Run:  uv run --project ../../craterpy python generate.py
"""

from pathlib import Path

import numpy as np
import pandas as pd

from craterpy import CraterDatabase

OUT = Path(__file__).parent

# Subset of Schroder et al. (2020), Table 1 rocky craters
# (https://doi.org/10.1016/j.icarus.2020.113871, data: zenodo 3833759).
# Native Dawn Claudia longitudes; spans lon/lat and includes the famous rayed
# craters Marcia and Oppia plus a near-pole (Severina) and a near-0/360 case.
dawn = pd.DataFrame(
    {
        "name": ["Marcia", "Oppia", "Aelia", "Antonia",
                 "Cornelia", "Licinia", "Severina", "Unnamed10"],
        "lon": [190.2, 308.9, 140.7, 200.9, 225.5, 17.2, 122.7, 358.4],
        "lat": [9.5, -7.6, -14.2, -58.9, -9.0, 23.6, -76.3, 15.1],
        "diam_km": [61.0, 34.0, 4.7, 17.3, 16.7, 23.6, 33.4, 10.1],
    }
)

# Load in the Dawn frame; read the standardized IAU:200000400 coords.
ddb = CraterDatabase(dawn.copy(), "vesta", input_crs="dawn_claudia", units="km")
std_lon = ddb.data["_lon"].to_numpy()  # IAU ocentric, -180..180
std_lat = ddb.data["_lat"].to_numpy()

# The IAU list: same craters, longitudes expressed in claudia_dp (ocentric),
# in 0..360 to mirror the Dawn list's style.
iau = dawn.copy()
iau["lon"] = np.round(std_lon % 360, 3)
iau["lat"] = np.round(std_lat, 3)

dawn.to_csv(OUT / "vesta_dawn_craters.csv", index=False)
iau.to_csv(OUT / "vesta_iau_craters.csv", index=False)

# Cross-check: loading the IAU list in claudia_dp reproduces the same
# standardized coords (the two lists are the same physical craters).
idb = CraterDatabase(iau.copy(), "vesta", input_crs="claudia_dp", units="km")
assert np.allclose(idb.data["_lon"], std_lon, atol=1e-6)
assert np.allclose(idb.data["_lat"], std_lat, atol=1e-6)

# Circle geometries (1 crater radius) in standardized IAU:200000400. These are
# identical for both inputs, proving the frame handling round-trips.
ddb.add_circles("circles", 1)
ddb.to_geojson(str(OUT / "vesta_dawn_circles.geojson"), "circles")
idb.add_circles("circles", 1)
idb.to_geojson(str(OUT / "vesta_iau_circles.geojson"), "circles")

# Synthetic edge-longitude table: the same input longitudes read as if in each
# frame, with craterpy's expected standardized lon (IAU:200000400, -180..180).
# Includes 180 / 356 to exercise antimeridian wrap.
edge_lon = [0.0, 90.0, 146.0, 180.0, 270.0, 356.0]
edge_lat = [0.0, 30.0, -4.3, -60.0, 45.0, 0.0]
edge = pd.DataFrame({"input_lon": edge_lon, "lat": edge_lat})
for frame in ["claudia_dp", "claudia_p", "dawn_claudia"]:
    df = pd.DataFrame({"lon": edge_lon, "lat": edge_lat, "diam_km": 10.0})
    db = CraterDatabase(df, "vesta", input_crs=frame, units="km")
    edge[f"std_lon_{frame}"] = np.round(db.data["_lon"].to_numpy(), 3)
edge.to_csv(OUT / "edge_cases.csv", index=False)

print("Wrote:", *(p.name for p in sorted(OUT.glob("*"))))
