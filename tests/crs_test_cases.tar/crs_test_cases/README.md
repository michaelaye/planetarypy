# Vesta CRS test cases

Practical examples of craterpy's Vesta coordinate handling, for validating
planetarypy's CRS support. Generated with craterpy (`generate.py`).

Vesta is mapped in several longitude frames that differ only by a prime-meridian
offset. craterpy exposes them as aliases on the `vesta` body; all standardize to
IAU:200000400 (ocentric, lon in −180..180):

| alias | definition | offset vs ocentric | in planetarypy? |
|---|---|---|---|
| `claudia_dp` | `IAU_2015:200000400` | 0° | yes (generative) |
| `claudia_p` | `+proj=longlat +R=255000 +lon_0=+10` | +10° | no |
| `dawn_claudia` | `+proj=longlat +R=255000 +lon_0=-210` | +150° (−210 mod 360) | no |

`claudia_p` and `dawn_claudia` are the cases that need craterpy's custom handling
— planetarypy's `body_crs` only generates the ocentric/ographic codes.

## Files

- **`vesta_dawn_craters.csv`** — 8 named craters in the **Dawn Claudia** frame
  (native Schröder longitudes). Read with `input_crs="dawn_claudia"`.
- **`vesta_iau_craters.csv`** — the **same physical craters** in the
  **claudia_dp / IAU ocentric** frame. Read with `input_crs="claudia_dp"`.
- **`vesta_dawn_circles.geojson` / `vesta_iau_circles.geojson`** — 1-radius circle
  geometries from the two lists, in IAU:200000400. The two files are
  **geometrically identical** — that equality is the round-trip test.
- **`edge_cases.csv`** — synthetic longitudes (incl. 180°/356° for antimeridian
  wrap) read in each frame, with craterpy's expected standardized `std_lon_*`.
- **`generate.py`** — reproduces everything.

## How to verify

Load each crater list with the `input_crs` named above and standardize to
IAU:200000400 (−180..180). `vesta_dawn` and `vesta_iau` must yield identical
lon/lat (and identical circle geometry). For `edge_cases.csv`, reading
`input_lon` in a given frame must reproduce that frame's `std_lon_*` column.

Anchor: **Marcia** crater sits at 190.2°E (Dawn) = 340.2°E (IAU); **Claudia**
crater at 356°E (Dawn) = 146°E (IAU).

Source: Schröder et al. (2020), Icarus 113871 (data: Zenodo 3833759).
